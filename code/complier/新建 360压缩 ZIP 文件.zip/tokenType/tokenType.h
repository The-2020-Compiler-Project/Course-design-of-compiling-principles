//
// Created by YCJ on 2020/6/30.
//

#ifndef COMPLIER_TOKENTYPE_H
#define COMPLIER_TOKENTYPE_H
//tokenType定义
//Kt关键字，Pt界符，It标识符，Ct字符常量，St字符串常量，Nt整型常量，Rt浮点型常量
enum tokenType{Kt,Pt,It,Ct,St,Nt,Rt};

#endif //COMPLIER_TOKENTYPE_H
